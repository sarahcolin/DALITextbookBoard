import React, { Component } from 'react';
import { Map } from 'immutable';
import TextbookPosting from './textbookPosting';
import * as db from './datastore';


class TextbookBoard extends Component {
    constructor(props) {
        super(props);
        this.state = {textbooks: Map(), textbookID: 0, newTextbookName: "", newTextbookPrice: "", newTextbookImage: "", showAddTextbook: false};
    }

    newTextbookNameFunction = (event) => {
        this.setState({newTextbookName: event.target.value})
    }

    newTextbookPriceFunction = (event) => {
        this.setState({newTextbookPrice: event.target.value})
    }

    newTextbookImageFunction = (event) => {
        this.setState({newTextbookImage: event.target.value})
    }

    saveTextbookInfo = () => {
        var textbookData = {
            name: this.state.newTextbookName,
            price: this.state.newTextbookPrice,
            image: this.state.newTextbookImage,
        }

        db.addTextbook(this.state.newTextbookName, this.state.newTextbookPrice, this.state.newTextbookImage)

        this.setState({
             textbooks: this.state.textbooks.set(this.state.textbookID, textbookData),
             textbookID: this.state.textbookID +1,
             showAddTextbook: false,
             newTextbookName: "",
             newTextbookPrice: '',
             newTextbookImage: '',
        })
    
    }

    delete = (id) => {
        this.setState({textbooks: this.state.textbooks.delete(id)})
    }

    save = (id, field) => {
        this.setState({textbooks:this.state.textbooks.update(id, (n) => { return Object.assign({}, n, field); })})
    }

    showAddTextbook = () => {
        this.setState({showAddTextbook: true})
    }
    
    componentDidMount() {
        db.fetchTextbooks(this.fetchedTextbooks);
    }

    fetchedTextbooks = (allTextbooks) => {
        this.setState({textbooks: allTextbooks});
    }

    render() {

        const allTextbooks = this.state.textbooks.entrySeq().map(
            ([id, textbook]) => {
                return <TextbookPosting save={this.save} delete={this.delete} name={textbook.name} price={textbook.price} textbookURL={textbook.image} id={id}/>
            }
        )

        const addTextbook = this.state.showAddTextbook 
            

        return (
            <p> This is the textbook board </p>

            <input placeholder="name" type="text" value={this.state.newTextbookName} onChange={this.newTextbookNameFunction}/>

            <input placeholder="price" type="text" value={this.state.newTextbookPrice} onChange={this.newTextbookPriceFunction} />

            <input placeholder="imageURL" type="text" value={this.state.newTextbookImage} onChange={this.newTextbookImageFunction} />

            <button onClick={this.saveTextbookInfo}>Save</button>
                
            <button> onClick={this.showAddTextbook} Add a Textbook </button>

            {addTextbook}

            {allDogs}
        )
    }
}



export default TextbookBoard;